import socket
import sys
import argparse

# Crear el parser de argumentos
parser = argparse.ArgumentParser(description="Servidor de mayúsculas.")
parser.add_argument('-p', '--port', type=int, help='Número de puerto para escuchar las conexiones del cliente.', default=1026)
args = parser.parse_args()

# Crear el socket TCP
servidor_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
servidor_ip = '0.0.0.0'  # Escuchar en todas las interfaces

# Asignar dirección IP y puerto al socket
servidor_socket.bind((servidor_ip, args.port))
servidor_socket.listen(5)
print(f"Servidor escuchando en {servidor_ip}:{args.port}...")

# Aceptar la conexión del cliente
conn, address = servidor_socket.accept()
print(f"Conexión aceptada de {address[0]}:{address[1]}")

# Procesar línea por línea
while True:
    try:
        datos = conn.recv(1024).decode()  # Recibir datos del cliente
        if not datos:  # Si no hay más datos, salir del bucle
            break
        
        # Convertir la línea a mayúsculas
        datos_mayus = datos.upper()
        
        # Enviar respuesta al cliente
        conn.send(datos_mayus.encode('utf-8'))

        # Imprimir el mensaje procesado y su longitud
        print(f"Mensaje procesado: {datos_mayus} (Longitud: {len(datos_mayus.encode('utf-8'))} bytes)")
    except Exception as e:
        print(f"Error: {e}")
        break

# Cerrar la conexión
print("Cerrando conexión del servidor.")
conn.close()
servidor_socket.close()
