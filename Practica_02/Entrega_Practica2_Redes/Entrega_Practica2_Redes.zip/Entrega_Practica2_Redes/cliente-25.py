import socket
import sys
import argparse

# Crear el parser de argumentos
parser = argparse.ArgumentParser(description="Cliente para enviar archivo al servidor y recibir en mayúsculas.")
parser.add_argument('-i', '--ip', type=str, help='Dirección IP del servidor', default='127.0.0.1')
parser.add_argument('-p', '--port', type=int, help='Puerto del servidor', default=1026)
parser.add_argument('-f', '--file', type=str, help='Archivo de texto de entrada', default='archivo.txt')

args = parser.parse_args()
# Parámetros de entrada con valores predeterminados
cliente_ip = args.ip if args.ip else '127.0.0.1'
puerto = args.port if args.port else 1026
archivo_entrada = args.file if args.file else "archivo.txt"

# Abrir el archivo de entrada en modo lectura
try:
    with open(args.file, 'r', encoding='utf-8') as archivo:
        lineas = archivo.readlines()
except FileNotFoundError:
    print(f"Error: El archivo {args.file} no se encontró.")
    sys.exit(1)

# Crear el socket TCP del cliente
cliente_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Conectarse al servidor
try:
    cliente_socket.connect((args.ip, args.port))
    print(f"Conectado al servidor {args.ip} en el puerto {args.port}.")
except socket.error as e:
    print(f"Error: No se pudo conectar al servidor en {args.ip}:{args.port} - {e}")
    sys.exit(1)
archivo_salida="archivo_salida.cap"
# Abrir el archivo de salida en modo escritura
with open(archivo_salida, 'w', encoding='utf-8') as archivo_salida:
    # Enviar las líneas al servidor y recibir las respuestas
    for linea in lineas:
        frase_con_punto = linea.strip() + '.'  # Agregar un punto al final de la línea
        print(f"Enviando frase: {frase_con_punto} (Longitud: {len(frase_con_punto.encode('utf-8'))} bytes)")
        
        # Enviar la frase
        cliente_socket.send(frase_con_punto.encode('utf-8'))
        
        # Recibir la respuesta del servidor
        respuesta = cliente_socket.recv(1024).decode()
        print(f"Mensaje recibido del servidor: {respuesta} (Longitud: {len(respuesta.encode('utf-8'))} bytes)")

        # Escribir la respuesta en el archivo de salida
        archivo_salida.write(respuesta + '\n')

# Cerrar la conexión
print("Cerrando conexión del cliente.")
cliente_socket.close()
