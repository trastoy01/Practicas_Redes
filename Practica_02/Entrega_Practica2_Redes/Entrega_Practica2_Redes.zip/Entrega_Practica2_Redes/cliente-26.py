import socket
import sys
import argparse
import time

# Crear el parser de argumentos
parser = argparse.ArgumentParser(description="Cliente para enviar archivo al servidor y recibir en mayúsculas.")
parser.add_argument('-i', '--ip', type=str, help='Dirección IP del servidor', required=False)
parser.add_argument('-p', '--port', type=int, help='Puerto del servidor', required=False)
parser.add_argument('-f', '--file', type=str, help='Archivo de texto de entrada', required=False)
args = parser.parse_args()

# Parámetros de entrada con valores predeterminados
cliente_ip = args.ip if args.ip else '127.0.0.1'
puerto = args.port if args.port else 1026
archivo_entrada = args.file if args.file else "archivo.txt"

# Abrir el archivo de entrada en modo lectura
try:
    with open(archivo_entrada, 'r', encoding='utf-8') as archivo:
        contenido = archivo.read()
except FileNotFoundError:
    print(f"Error: El archivo {archivo_entrada} no se encontró.")
    sys.exit(1)

# Se eliminan los espacios en blanco al inicio y al final de cada frase
frases = [frase.strip() for frase in contenido.split('.') if frase.strip()]

# Imprimir la lista de frases
print("Frases extraídas del archivo")
#for i, frase in enumerate(frases, 1):
    #print(f"{i}: {frase}")

# Crear el socket TCP del cliente
try:
    cliente_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
except socket.error as e:
    print(f"Error al crear el socket: {e}")
    sys.exit(1)

# Conectarse al servidor
try:
    cliente_socket.connect((cliente_ip, puerto))
    print(f"Conectado al servidor {cliente_ip} en el puerto {puerto}.")
except socket.error as e:
    print(f"Error: No se pudo conectar al servidor en {cliente_ip}:{puerto} - {e}")
    sys.exit(1)

# Enviar las frases al servidor
for frase in frases:
    frase_con_punto = frase + '.'  # Agregar un punto al final de la frase
    try:
        print(f"Enviando frase: {frase_con_punto} (Longitud: {len(frase_con_punto.encode('utf-8'))} bytes)")
        cliente_socket.send(frase_con_punto.encode('utf-8'))
    except socket.error as e:
        print(f"Error al enviar datos: {e}")
        cliente_socket.close()
        sys.exit(1)
    time.sleep(2)  # Esperar 2 segundos antes de enviar la siguiente

# Usar shutdown para indicar que ya no se enviarán más datos
try:
    cliente_socket.shutdown(socket.SHUT_WR)
except socket.error as e:
    print(f"Error al cerrar la conexión de escritura: {e}")
    cliente_socket.close()
    sys.exit(1)

# Recibir la respuesta del servidor

texto = []
while True:
    try:
        mensaje = cliente_socket.recv(10).decode()  # Buffer de recepción de 1024 bytes
    except socket.error as e:
        print(f"Error al recibir datos: {e}")
        cliente_socket.close()
        sys.exit(1)
    if len(mensaje) == 0:
        print("El servidor cerró la conexión.")
        break
    else:
        # Imprimir el mensaje y su longitud en bytes
        texto.append(mensaje)
        print(f"Mensaje recibido del servidor: {mensaje} (Longitud: {len(mensaje.encode('utf-8'))} bytes)")

# Cerrar la conexión
print("Cerrando conexión cliente-25")
try:
    cliente_socket.close()
except socket.error as e:
    print(f"Error al cerrar el socket: {e}")
    sys.exit(1)

# Guardar la respuesta en un archivo de salida
archivo_salida = "archivo.cap"
contenido = ''
for linea in texto:
    contenido += linea  # Concatenar cada línea

frases = contenido.split('.')

try:
    with open(archivo_salida, 'w', encoding='utf-8') as archivo_out:
        for frase in frases:
            frase = frase.strip()  # Eliminar espacios en blanco al inicio y al final
            if frase:  # Si la frase no está vacía
                archivo_out.write(frase.upper() + '.\n')  # Escribir en mayúsculas, con punto y salto de línea
except IOError as e:
    print(f"Error al escribir en el archivo de salida: {e}")
    sys.exit(1)
