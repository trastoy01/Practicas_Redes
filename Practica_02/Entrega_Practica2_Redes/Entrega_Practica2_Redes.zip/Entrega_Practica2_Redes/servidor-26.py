import socket
import sys
import argparse

# Crear el parser de argumentos
parser = argparse.ArgumentParser(description="Servidor de mayúsculas.")
parser.add_argument('-p', '--port', type=int, help='Número de puerto para escuchar las conexiones del cliente.')
args = parser.parse_args()

# Procesar el argumento -p (Número de puerto)
puerto = args.port if args.port else 1026

# Crear el socket TCP
try:
    servidor_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
except socket.error as e:
    print(f"Error al crear el socket: {e}")
    sys.exit(1)

# Dirección IP y puerto a usar
servidor_ip = '0.0.0.0'  # Escuchar en todas las interfaces

# Asignar dirección IP y puerto al socket
try:
    servidor_socket.bind((servidor_ip, puerto))
except socket.error as e:
    print(f"Error al asignar la dirección y el puerto: {e}")
    servidor_socket.close()
    sys.exit(1)

# Configurar el servidor para escuchar conexiones
try:
    servidor_socket.listen(5)
    print(f"Servidor escuchando en {servidor_ip}:{puerto}...")
except socket.error as e:
    print(f"Error al configurar el servidor para escuchar: {e}")
    servidor_socket.close()
    sys.exit(1)

# Aceptar la conexión del cliente
try:
    conn, address = servidor_socket.accept()
    print(f"Conexión aceptada de {address[0]}:{address[1]}")
except socket.error as e:
    print(f"Error al aceptar la conexión del cliente: {e}")
    servidor_socket.close()
    sys.exit(1)

texto = []

# Recepción de datos y procesamiento
while True:
    try:
        datos = conn.recv(20).decode()  # Buffer de recepción de 1024 bytes
    except socket.error as e:
        print(f"Error al recibir datos: {e}")
        conn.close()
        servidor_socket.close()
        sys.exit(1)

    if not datos:  # Si no hay más datos, salir del bucle
        break
    if datos.endswith("fin") and datos != "fin":
        datos = datos[:-3]
        texto.append(datos.upper())
        print(f"Mensaje procesado: {datos.upper()} (Longitud: {len(datos.encode('utf-8'))} bytes)")
        break

    # Convertir la línea a mayúsculas
    datos_mayus = datos.upper()
    texto.append(datos_mayus)
    print(f"Mensaje procesado: {datos_mayus} (Longitud: {len(datos_mayus.encode('utf-8'))} bytes)")

    # Enviar respuesta al cliente
    try:
        conn.send(datos_mayus.encode('utf-8'))
    except socket.error as e:
        print(f"Error al enviar datos al cliente: {e}")
        conn.close()
        servidor_socket.close()
        sys.exit(1)

# Cerrar la conexión
print("Cerrando conexión servidor-25")
try:
    conn.close()
    servidor_socket.close()
except socket.error as e:
    print(f"Error al cerrar el socket: {e}")
    sys.exit(1)
